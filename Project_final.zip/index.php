<?php
// Entry point for the Grocery E-Commerce Application

// Start session
session_start();

// Include configuration
require_once 'config/database.php';

// Autoload classes (basic implementation)
spl_autoload_register(function ($class_name) {
    $paths = [
        'app/models/',
        'app/controllers/',
        'app/helpers/'
    ];

    foreach ($paths as $path) {
        $file = $path . $class_name . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Basic routing
$request = $_SERVER['REQUEST_URI'];
$base_path = '/'; // Adjust if your app is in a subdirectory

// Remove query string first
$request = explode('?', $request)[0];

// Remove only the leading slash, preserve internal slashes
$request = ltrim($request, '/');

// Handle the case where the request might be "products1" instead of "products/1"
if (preg_match('/^products(\d+)$/', $request, $matches)) {
    $request = 'products/' . $matches[1];
}

// Debug: Log the request for troubleshooting
error_log("Request: '" . $request . "' | Full URI: '" . $_SERVER['REQUEST_URI'] . "'");

// Default route
if ($request === '' || $request === '/') {
    $controller = new HomeController();
    $controller->index();
} elseif ($request === 'login') {
    $controller = new AuthController();
    $controller->login();
} elseif ($request === 'signup') {
    $controller = new AuthController();
    $controller->signup();
} elseif ($request === 'logout') {
    $controller = new AuthController();
    $controller->logout();
} elseif ($request === 'products') {
    $controller = new ProductController();
    $controller->index();
} elseif (preg_match('/products\/(\d+)/', $request, $matches)) {
    $controller = new ProductController();
    $controller->show($matches[1]);
} elseif ($request === 'cart') {
    $controller = new CartController();
    $controller->index();
} elseif ($request === 'cart/add') {
    $controller = new CartController();
    $controller->add();
} elseif ($request === 'cart/count') {
    $controller = new CartController();
    $controller->count();
} elseif ($request === 'cart/totals') {
    $controller = new CartController();
    $controller->totals();
} elseif ($request === 'cart/update') {
    $controller = new CartController();
    $controller->update();
} elseif ($request === 'cart/remove') {
    $controller = new CartController();
    $controller->remove();
} elseif ($request === 'cart/clear') {
    $controller = new CartController();
    $controller->clear();
} elseif ($request === 'cart/apply-coupon') {
    $controller = new CartController();
    $controller->applyCoupon();
} elseif ($request === 'cart/remove-coupon') {
    $controller = new CartController();
    $controller->removeCoupon();
} elseif ($request === 'coupons/active') {
    $controller = new CouponController();
    $controller->getActiveCoupons();
} elseif ($request === 'checkout') {
    $controller = new CheckoutController();
    $controller->index();
} elseif ($request === 'checkout/process') {
    $controller = new CheckoutController();
    $controller->process();
} elseif ($request === 'checkout/success') {
    include 'app/views/checkout/success.php';
    exit;
} elseif ($request === 'profile') {
    $controller = new ProfileController();
    $controller->index();
} elseif ($request === 'orders') {
    $controller = new OrdersController();
    $controller->index();
} elseif (preg_match('/^orders\/(\d+)$/', $request, $matches)) {
    $controller = new OrdersController();
    $controller->show($matches[1]);
} elseif (preg_match('/^orders\/track\/(\d+)$/', $request, $matches)) {
    $controller = new OrdersController();
    $controller->track($matches[1]);
} elseif ($request === 'orders/cancel') {
    $controller = new OrdersController();
    $controller->cancel();
} elseif ($request === 'orders/reorder') {
    $controller = new OrdersController();
    $controller->reorder();
} elseif ($request === 'orders/reorder-all') {
    $controller = new OrdersController();
    $controller->reorderAll();
} elseif ($request === 'profile/update') {
    $controller = new ProfileController();
    $controller->update();
} elseif ($request === 'profile/add-address') {
    $controller = new ProfileController();
    $controller->addAddress();
} elseif ($request === 'profile/update-address') {
    $controller = new ProfileController();
    $controller->updateAddress();
} elseif ($request === 'profile/delete-address') {
    $controller = new ProfileController();
    $controller->deleteAddress();
} elseif (preg_match('/^profile\/address\/(\d+)$/', $request, $matches)) {
    $controller = new ProfileController();
    $controller->getAddress($matches[1]);
} elseif ($request === 'profile/save-diet-profile') {
    $controller = new ProfileController();
    $controller->saveDietProfile();
} elseif ($request === 'subscriptions') {
    $controller = new SubscriptionsController();
    $controller->index();
} elseif ($request === 'subscriptions/create') {
    $controller = new SubscriptionsController();
    $controller->create();
} elseif ($request === 'subscriptions/store') {
    $controller = new SubscriptionsController();
    $controller->store();
} elseif (preg_match('/^subscriptions\/pause\/(\d+)$/', $request, $matches)) {
    $controller = new SubscriptionsController();
    $controller->pause($matches[1]);
} elseif (preg_match('/^subscriptions\/resume\/(\d+)$/', $request, $matches)) {
    $controller = new SubscriptionsController();
    $controller->resume($matches[1]);
} elseif (preg_match('/^subscriptions\/cancel\/(\d+)$/', $request, $matches)) {
    $controller = new SubscriptionsController();
    $controller->cancel($matches[1]);
} elseif ($request === 'admin') {
    $controller = new AdminController();
    $controller->dashboard();
} elseif ($request === 'admin/subscriptions') {
    $controller = new AdminController();
    $controller->subscriptions();
} elseif ($request === 'admin/create-subscription') {
    $controller = new AdminController();
    $controller->usersForSubscription();
} elseif ($request === 'admin/create-subscription/store') {
    $controller = new AdminController();
    $controller->createSubscription();
} elseif ($request === 'admin/products') {
    $controller = new AdminController();
    $controller->products();
} elseif ($request === 'admin/products/create') {
    $controller = new AdminController();
    $controller->createProduct();
} elseif (preg_match('/^admin\/products\/edit\/(\d+)$/', $request, $matches)) {
    $controller = new AdminController();
    $controller->editProduct($matches[1]);
} elseif (preg_match('/^admin\/products\/delete\/(\d+)$/', $request, $matches)) {
    $controller = new AdminController();
    $controller->deleteProduct($matches[1]);
} elseif ($request === 'admin/categories') {
    $controller = new AdminController();
    $controller->categories();
} elseif ($request === 'admin/categories/create') {
    $controller = new AdminController();
    $controller->createCategory();
} elseif (preg_match('/^admin\/categories\/edit\/(\d+)$/', $request, $matches)) {
    $controller = new AdminController();
    $controller->editCategory($matches[1]);
} elseif (preg_match('/^admin\/categories\/delete\/(\d+)$/', $request, $matches)) {
    $controller = new AdminController();
    $controller->deleteCategory($matches[1]);
} elseif ($request === 'admin/orders') {
    $controller = new AdminController();
    $controller->orders();
} elseif ($request === 'admin/orders/update-status') {
    $controller = new AdminController();
    $controller->updateOrderStatus();
} else {
    // 404 - Page not found
    http_response_code(404);
    include 'app/views/errors/404.php';
    exit;
}
?>