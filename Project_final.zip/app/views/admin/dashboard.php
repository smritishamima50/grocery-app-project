<?php
$title = 'Admin Dashboard - GroceryApp';
ob_start();
?>

<div class="max-w-7xl mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-8">
        <h1 class="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
        <a href="/" class="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700">
            Back to Store
        </a>
    </div>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center">
                <div class="p-3 bg-blue-100 rounded-full">
                    <i class="fas fa-shopping-cart text-blue-600 text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-gray-600">Total Orders</p>
                    <p class="text-2xl font-bold"><?php echo number_format($stats['total_orders']); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center">
                <div class="p-3 bg-green-100 rounded-full">
                    <i class="fas fa-dollar-sign text-green-600 text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-gray-600">Total Revenue</p>
                    <p class="text-2xl font-bold">৳<?php echo number_format($stats['total_revenue'], 2); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center">
                <div class="p-3 bg-purple-100 rounded-full">
                    <i class="fas fa-users text-purple-600 text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-gray-600">Total Users</p>
                    <p class="text-2xl font-bold"><?php echo number_format($stats['total_users']); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center">
                <div class="p-3 bg-orange-100 rounded-full">
                    <i class="fas fa-box text-orange-600 text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-gray-600">Total Products</p>
                    <p class="text-2xl font-bold"><?php echo number_format($stats['total_products']); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <a href="/admin/products" class="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition duration-300">
            <div class="flex items-center">
                <i class="fas fa-box text-2xl text-blue-600 mr-4"></i>
                <div>
                    <h3 class="font-semibold">Manage Products</h3>
                    <p class="text-gray-600 text-sm">Add, edit, or remove products</p>
                </div>
            </div>
        </a>

        <a href="/admin/orders" class="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition duration-300">
            <div class="flex items-center">
                <i class="fas fa-clipboard-list text-2xl text-green-600 mr-4"></i>
                <div>
                    <h3 class="font-semibold">Manage Orders</h3>
                    <p class="text-gray-600 text-sm">View and update order status</p>
                </div>
            </div>
        </a>

        <a href="/admin/categories" class="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition duration-300">
            <div class="flex items-center">
                <i class="fas fa-tags text-2xl text-purple-600 mr-4"></i>
                <div>
                    <h3 class="font-semibold">Manage Categories</h3>
                    <p class="text-gray-600 text-sm">Organize product categories</p>
                </div>
            </div>
        </a>

        <a href="/admin/subscriptions" class="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition duration-300">
            <div class="flex items-center">
                <i class="fas fa-sync-alt text-2xl text-orange-600 mr-4"></i>
                <div>
                    <h3 class="font-semibold">Manage Subscriptions</h3>
                    <p class="text-gray-600 text-sm">Create and manage subscriptions</p>
                </div>
            </div>
        </a>
    </div>

    <!-- Recent Orders -->
    <div class="bg-white rounded-lg shadow-md">
        <div class="p-6 border-b border-gray-200">
            <h2 class="text-xl font-semibold">Recent Orders</h2>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php if (empty($recentOrders)): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-4 text-center text-gray-500">No orders found</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($recentOrders as $order): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">#<?php echo $order['id']; ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">৳<?php echo number_format($order['total_amount'], 2); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                        <?php
                                        switch ($order['status']) {
                                            case 'placed': echo 'bg-yellow-100 text-yellow-800'; break;
                                            case 'confirmed': echo 'bg-blue-100 text-blue-800'; break;
                                            case 'packed': echo 'bg-purple-100 text-purple-800'; break;
                                            case 'shipped': echo 'bg-indigo-100 text-indigo-800'; break;
                                            case 'delivered': echo 'bg-green-100 text-green-800'; break;
                                            case 'cancelled': echo 'bg-red-100 text-red-800'; break;
                                            default: echo 'bg-gray-100 text-gray-800';
                                        }
                                        ?>">
                                        <?php echo ucfirst($order['status']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo date('M d, Y', strtotime($order['created_at'])); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <a href="/admin/orders?status=<?php echo $order['status']; ?>" class="text-blue-600 hover:text-blue-900">View</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="p-6 border-t border-gray-200">
            <a href="/admin/orders" class="text-blue-600 hover:text-blue-900 font-medium">View all orders →</a>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include 'app/views/layouts/main.php';
?>