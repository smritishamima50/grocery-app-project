<?php
require_once 'BaseController.php';

class AdminController extends BaseController {
    public function __construct() {
        parent::__construct();
        $this->requireAdmin();
    }

    public function dashboard() {
        // Get dashboard statistics
        $stats = [];

        // Total orders
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as total_orders FROM orders");
        $stmt->execute();
        $stats['total_orders'] = $stmt->fetch()['total_orders'];

        // Total revenue
        $stmt = $this->pdo->prepare("SELECT SUM(total_amount) as total_revenue FROM orders WHERE status = 'delivered'");
        $stmt->execute();
        $stats['total_revenue'] = $stmt->fetch()['total_revenue'] ?? 0;

        // Total users
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as total_users FROM users WHERE role = 'customer'");
        $stmt->execute();
        $stats['total_users'] = $stmt->fetch()['total_users'];

        // Total products
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as total_products FROM products");
        $stmt->execute();
        $stats['total_products'] = $stmt->fetch()['total_products'];

        // Recent orders
        $stmt = $this->pdo->prepare("
            SELECT o.*, u.first_name, u.last_name
            FROM orders o
            JOIN users u ON o.user_id = u.id
            ORDER BY o.created_at DESC LIMIT 10
        ");
        $stmt->execute();
        $recentOrders = $stmt->fetchAll();

        $this->render('admin/dashboard', [
            'stats' => $stats,
            'recentOrders' => $recentOrders
        ]);
    }

    public function products() {
        $page = $_GET['page'] ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $stmt = $this->pdo->prepare("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id LIMIT $limit OFFSET $offset");
        $stmt->execute();
        $products = $stmt->fetchAll();

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as total FROM products");
        $stmt->execute();
        $total = $stmt->fetch()['total'];
        $totalPages = ceil($total / $limit);

        $this->render('admin/products', [
            'products' => $products,
            'currentPage' => $page,
            'totalPages' => $totalPages
        ]);
    }

    public function orders() {
        $status = $_GET['status'] ?? null;
        $page = $_GET['page'] ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $where = $status ? "WHERE status = ?" : "";
        $params = $status ? [$status] : [];

        $stmt = $this->pdo->prepare("
            SELECT o.*, u.first_name, u.last_name
            FROM orders o
            JOIN users u ON o.user_id = u.id
            $where
            ORDER BY o.created_at DESC LIMIT $limit OFFSET $offset
        ");
        $stmt->execute($params);
        $orders = $stmt->fetchAll();

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as total FROM orders $where");
        $stmt->execute($params);
        $total = $stmt->fetch()['total'];
        $totalPages = ceil($total / $limit);

        $this->render('admin/orders', [
            'orders' => $orders,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'status' => $status
        ]);
    }

    public function updateOrderStatus() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $orderId = $_POST['order_id'] ?? 0;
            $status = $_POST['status'] ?? '';

            $stmt = $this->pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
            $stmt->execute([$status, $orderId]);

            // Add delivery update
            $stmt = $this->pdo->prepare("INSERT INTO delivery_updates (order_id, status, message) VALUES (?, ?, ?)");
            $stmt->execute([$orderId, $status, "Order status updated to $status"]);

            $this->redirect('/admin/orders');
        }
    }

    // Subscription Management
    public function surpriseGifts() {
        // Get all surprise gifts
        $stmt = $this->pdo->query("
            SELECT sg.*, p.name as product_name, p.price
            FROM surprise_gifts sg
            JOIN products p ON sg.product_id = p.id
            ORDER BY sg.created_at DESC
        ");
        $surpriseGifts = $stmt->fetchAll();
        
        // Get all products for the dropdown
        $stmt = $this->pdo->query("SELECT id, name, price FROM products ORDER BY name");
        $products = $stmt->fetchAll();
        
        // Calculate success rate (simplified)
        $totalOrders = $this->pdo->query("SELECT COUNT(*) as count FROM orders")->fetch()['count'];
        $totalGiftUses = array_sum(array_column($surpriseGifts, 'current_uses'));
        $successRate = $totalOrders > 0 ? round(($totalGiftUses / $totalOrders) * 100, 1) : 0;
        
        $this->render('admin/surprise-gifts', [
            'surpriseGifts' => $surpriseGifts,
            'products' => $products,
            'successRate' => $successRate
        ]);
    }
    
    public function saveSurpriseGift() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $giftId = $_POST['gift_id'] ?? null;
            $name = $_POST['name'];
            $description = $_POST['description'];
            $productId = $_POST['product_id'];
            $quantity = $_POST['quantity'];
            $triggerType = $_POST['trigger_type'];
            $triggerValue = $_POST['trigger_value'];
            $probabilityPercentage = $_POST['probability_percentage'];
            $isActive = isset($_POST['is_active']) ? 1 : 0;
            
            if ($giftId) {
                // Update existing gift
                $stmt = $this->pdo->prepare("
                    UPDATE surprise_gifts 
                    SET name = ?, description = ?, product_id = ?, quantity = ?, 
                        trigger_type = ?, trigger_value = ?, probability_percentage = ?, is_active = ?
                    WHERE id = ?
                ");
                $stmt->execute([$name, $description, $productId, $quantity, $triggerType, $triggerValue, $probabilityPercentage, $isActive, $giftId]);
            } else {
                // Create new gift
                $stmt = $this->pdo->prepare("
                    INSERT INTO surprise_gifts (name, description, product_id, quantity, trigger_type, trigger_value, probability_percentage, is_active)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$name, $description, $productId, $quantity, $triggerType, $triggerValue, $probabilityPercentage, $isActive]);
            }
            
            $this->redirect('/admin/surprise-gifts');
        }
    }

    public function subscriptions() {
        $stmt = $this->pdo->prepare("
            SELECT s.*, u.first_name, u.last_name, u.email,
                   ua.address_line1, ua.city, ua.state
            FROM subscriptions s
            JOIN users u ON s.user_id = u.id
            LEFT JOIN user_addresses ua ON s.delivery_address_id = ua.id
            ORDER BY s.created_at DESC
        ");
        $stmt->execute();
        $subscriptions = $stmt->fetchAll();

        // Parse product IDs for each subscription
        foreach ($subscriptions as &$subscription) {
            $subscription['product_ids_array'] = json_decode($subscription['product_ids'], true) ?? [];
        }

        $this->render('admin/subscriptions', [
            'subscriptions' => $subscriptions
        ]);
    }

    public function usersForSubscription() {
        // Get all users (customers)
        $stmt = $this->pdo->prepare("SELECT id, first_name, last_name, email FROM users WHERE role = 'customer' ORDER BY first_name, last_name");
        $stmt->execute();
        $users = $stmt->fetchAll();

        // Get all products
        $stmt = $this->pdo->prepare("SELECT id, name, price, image, unit FROM products ORDER BY name");
        $stmt->execute();
        $products = $stmt->fetchAll();

        $this->render('admin/create-subscription', [
            'users' => $users,
            'products' => $products
        ]);
    }

    public function createSubscription() {
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userId = $_POST['user_id'] ?? 0;
            $frequency = $_POST['frequency'] ?? 'monthly';
            $amount = floatval($_POST['amount'] ?? 0); // 200, 500, or 1000 tk
            $deliveryAddressId = $_POST['delivery_address_id'] ?? null;
            $deliverySlot = $_POST['delivery_slot'] ?? '';

            // Calculate next delivery date based on frequency
            $nextDeliveryDate = $this->calculateNextDeliveryDate($frequency);
            
            // Store product IDs as empty JSON since this is an amount-based subscription
            $productIds = [];

            try {
                $stmt = $this->pdo->prepare("
                    INSERT INTO subscriptions 
                    (user_id, frequency, payment_method, delivery_address_id, delivery_slot_preference, 
                     product_ids, next_delivery_date, amount, status, start_date)
                    VALUES (?, ?, 'cash_on_delivery', ?, ?, ?, ?, ?, 'active', CURDATE())
                ");
                
                $stmt->execute([
                    $userId,
                    $frequency,
                    $deliveryAddressId,
                    $deliverySlot,
                    json_encode($productIds),
                    $nextDeliveryDate,
                    $amount
                ]);

                echo json_encode([
                    'success' => true, 
                    'message' => 'Subscription created successfully',
                    'redirect' => '/admin/subscriptions'
                ]);
            } catch (PDOException $e) {
                error_log("Subscription creation error: " . $e->getMessage());
                echo json_encode(['success' => false, 'message' => 'Failed to create subscription']);
            }
        }
    }

    public function categories() {
        $stmt = $this->pdo->prepare("SELECT * FROM categories ORDER BY name");
        $stmt->execute();
        $categories = $stmt->fetchAll();

        $this->render('admin/categories', [
            'categories' => $categories
        ]);
    }

    public function createCategory() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'] ?? '';
            $description = $_POST['description'] ?? '';
            $image = $_POST['image'] ?? '';

            if ($name) {
                $stmt = $this->pdo->prepare("INSERT INTO categories (name, description, image) VALUES (?, ?, ?)");
                $stmt->execute([$name, $description, $image]);
                $this->redirect('/admin/categories');
            }
        }

        $this->render('admin/create-category');
    }

    public function editCategory($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        $category = $stmt->fetch();

        if (!$category) {
            $this->redirect('/admin/categories');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'] ?? '';
            $description = $_POST['description'] ?? '';
            $image = $_POST['image'] ?? '';

            if ($name) {
                $stmt = $this->pdo->prepare("UPDATE categories SET name = ?, description = ?, image = ? WHERE id = ?");
                $stmt->execute([$name, $description, $image, $id]);
                $this->redirect('/admin/categories');
            }
        }

        $this->render('admin/edit-category', [
            'category' => $category
        ]);
    }

    public function deleteCategory($id) {
        // Check if category has products
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as count FROM products WHERE category_id = ?");
        $stmt->execute([$id]);
        $productCount = $stmt->fetch()['count'];

        if ($productCount > 0) {
            $_SESSION['error'] = "Cannot delete category with existing products. Please move or delete products first.";
        } else {
            $stmt = $this->pdo->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['success'] = "Category deleted successfully.";
        }

        $this->redirect('/admin/categories');
    }

    public function createProduct() {
        $stmt = $this->pdo->prepare("SELECT * FROM categories ORDER BY name");
        $stmt->execute();
        $categories = $stmt->fetchAll();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'] ?? '';
            $description = $_POST['description'] ?? '';
            $price = floatval($_POST['price'] ?? 0);
            $stock_quantity = intval($_POST['stock_quantity'] ?? 0);
            $unit = $_POST['unit'] ?? '';
            $category_id = intval($_POST['category_id'] ?? 0);
            $image = $_POST['image'] ?? '';
            $nutrition_info = $_POST['nutrition_info'] ?? '';

            if ($name && $price > 0 && $category_id > 0) {
                $stmt = $this->pdo->prepare("INSERT INTO products (name, description, price, stock_quantity, unit, category_id, image, nutrition_info) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $description, $price, $stock_quantity, $unit, $category_id, $image, $nutrition_info]);
                $this->redirect('/admin/products');
            }
        }

        $this->render('admin/create-product', [
            'categories' => $categories
        ]);
    }

    public function editProduct($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();

        if (!$product) {
            $this->redirect('/admin/products');
        }

        $stmt = $this->pdo->prepare("SELECT * FROM categories ORDER BY name");
        $stmt->execute();
        $categories = $stmt->fetchAll();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'] ?? '';
            $description = $_POST['description'] ?? '';
            $price = floatval($_POST['price'] ?? 0);
            $stock_quantity = intval($_POST['stock_quantity'] ?? 0);
            $unit = $_POST['unit'] ?? '';
            $category_id = intval($_POST['category_id'] ?? 0);
            $image = $_POST['image'] ?? '';
            $nutrition_info = $_POST['nutrition_info'] ?? '';

            if ($name && $price > 0 && $category_id > 0) {
                $stmt = $this->pdo->prepare("UPDATE products SET name = ?, description = ?, price = ?, stock_quantity = ?, unit = ?, category_id = ?, image = ?, nutrition_info = ? WHERE id = ?");
                $stmt->execute([$name, $description, $price, $stock_quantity, $unit, $category_id, $image, $nutrition_info, $id]);
                $this->redirect('/admin/products');
            }
        }

        $this->render('admin/edit-product', [
            'product' => $product,
            'categories' => $categories
        ]);
    }

    public function deleteProduct($id) {
        $stmt = $this->pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $_SESSION['success'] = "Product deleted successfully.";
        $this->redirect('/admin/products');
    }

    private function calculateNextDeliveryDate($frequency) {
        $date = new DateTime();
        
        switch ($frequency) {
            case 'weekly':
                $date->modify('+1 week');
                break;
            case 'bi_weekly':
                $date->modify('+2 weeks');
                break;
            case 'monthly':
                $date->modify('+1 month');
                break;
            default:
                $date->modify('+1 month');
        }
        
        return $date->format('Y-m-d');
    }
}
?>