<?php
require_once 'BaseController.php';
require_once 'app/helpers/SurpriseGiftHelper.php';

class CheckoutController extends BaseController {
    public function __construct() {
        parent::__construct();
        $this->requireLogin();
    }

    public function index() {
        $userId = $_SESSION['user_id'];

        // Get cart items
        $stmt = $this->pdo->prepare("
            SELECT ci.*, p.name, p.price, p.image, p.unit
            FROM cart_items ci
            JOIN products p ON ci.product_id = p.id
            WHERE ci.user_id = ?
        ");
        $stmt->execute([$userId]);
        $cartItems = $stmt->fetchAll();

        if (empty($cartItems)) {
            $this->redirect('/cart');
        }

        $total = 0;
        foreach ($cartItems as $item) {
            $total += $item['price'] * $item['quantity'];
        }

        // Calculate discount if coupon is applied
        $discount = 0;
        $appliedCoupon = null;
        if (isset($_SESSION['applied_coupon'])) {
            $appliedCoupon = $_SESSION['applied_coupon'];
            $discount = $appliedCoupon['discount_amount'];
        }

        $finalTotal = $total - $discount;

        // Get user addresses
        $stmt = $this->pdo->prepare("SELECT * FROM user_addresses WHERE user_id = ?");
        $stmt->execute([$userId]);
        $addresses = $stmt->fetchAll();

        // Add logging
        error_log("Checkout index - User ID: " . $userId);
        error_log("Checkout index - Cart items: " . count($cartItems));
        error_log("Checkout index - Addresses: " . count($addresses));

        $this->render('checkout/index', [
            'cartItems' => $cartItems,
            'total' => $total,
            'discount' => $discount,
            'finalTotal' => $finalTotal,
            'appliedCoupon' => $appliedCoupon,
            'addresses' => $addresses
        ]);
    }

    public function process() {
        // Add comprehensive logging
        error_log("=== CHECKOUT PROCESS STARTED ===");
        error_log("Request Method: " . $_SERVER['REQUEST_METHOD']);
        error_log("POST Data: " . print_r($_POST, true));
        error_log("Session Data: " . print_r($_SESSION, true));
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userId = $_SESSION['user_id'] ?? null;
            $addressId = $_POST['address_id'] ?? 0;
            $paymentMethod = $_POST['payment_method'] ?? 'cash_on_delivery';
            $deliverySlot = $_POST['delivery_slot'] ?? '';
            $packagingOption = $_POST['packaging_option'] ?? 'standard';

            error_log("User ID: " . $userId);
            error_log("Address ID: " . $addressId);
            error_log("Payment Method: " . $paymentMethod);
            error_log("Delivery Slot: " . $deliverySlot);
            error_log("Packaging Option: " . $packagingOption);

            if (!$userId) {
                error_log("ERROR: No user ID in session");
                $this->redirect('/login');
                return;
            }

            // Handle new address creation if no address_id provided
            if (!$addressId && isset($_POST['new_address_line1'])) {
                error_log("Creating new address...");
                $stmt = $this->pdo->prepare("
                    INSERT INTO user_addresses (user_id, address_type, address_line1, address_line2, city, state, zip_code, country, is_default)
                    VALUES (?, 'home', ?, ?, ?, ?, ?, ?, 1)
                ");
                $stmt->execute([
                    $userId,
                    $_POST['new_address_line1'],
                    $_POST['new_address_line2'] ?? '',
                    $_POST['new_city'],
                    $_POST['new_state'] ?? '',
                    $_POST['new_zip_code'] ?? '',
                    $_POST['new_country'] ?? 'Bangladesh'
                ]);
                $addressId = $this->pdo->lastInsertId();
                error_log("New address created with ID: " . $addressId);
            }

            // Validate that we have an address
            if (!$addressId) {
                error_log("ERROR: No address provided");
                $this->redirect('/checkout');
                return;
            }

            // Get cart items
            $stmt = $this->pdo->prepare("
                SELECT ci.*, p.price
                FROM cart_items ci
                JOIN products p ON ci.product_id = p.id
                WHERE ci.user_id = ?
            ");
            $stmt->execute([$userId]);
            $cartItems = $stmt->fetchAll();

            error_log("Cart Items Count: " . count($cartItems));
            error_log("Cart Items: " . print_r($cartItems, true));

            if (empty($cartItems)) {
                error_log("ERROR: No cart items found");
                $this->redirect('/cart');
                return;
            }

            $total = 0;
            foreach ($cartItems as $item) {
                $total += $item['price'] * $item['quantity'];
            }

            // Calculate discount if coupon is applied
            $discount = 0;
            $appliedCoupon = null;
            if (isset($_SESSION['applied_coupon'])) {
                $appliedCoupon = $_SESSION['applied_coupon'];
                $discount = $appliedCoupon['discount_amount'];
            }

            $finalTotal = $total - $discount;

            // Calculate packaging cost
            $packagingCost = 0;
            if ($packagingOption === 'reusable_bag') {
                $packagingCost = 20.00;
            }

            $finalTotalWithPackaging = $finalTotal + $packagingCost;

            error_log("Total Amount: " . $total);
            error_log("Discount: " . $discount);
            error_log("Packaging Cost: " . $packagingCost);
            error_log("Final Total: " . $finalTotal);
            error_log("Final Total with Packaging: " . $finalTotalWithPackaging);

            // Create order
            $this->pdo->beginTransaction();

            try {
                error_log("Creating order...");
                $stmt = $this->pdo->prepare("
                    INSERT INTO orders (user_id, total_amount, delivery_address_id, payment_method, delivery_slot, packaging_option, packaging_cost, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'placed')
                ");
                $stmt->execute([$userId, $finalTotalWithPackaging, $addressId, $paymentMethod, $deliverySlot, $packagingOption, $packagingCost]);
                $orderId = $this->pdo->lastInsertId();

                error_log("Order created with ID: " . $orderId);

                // Check for surprise gift eligibility
                $surpriseGiftHelper = new SurpriseGiftHelper($this->pdo);
                $userOrderCount = $this->getUserOrderCount($userId);
                
                // Check if user selected a surprise gift from cart
                $selectedSurpriseGift = null;
                if (isset($_POST['selected_surprise_gift']) && !empty($_POST['selected_surprise_gift'])) {
                    $selectedGiftIndex = intval($_POST['selected_surprise_gift']);
                    
                    // Get available surprise gifts
                    $stmt = $this->pdo->prepare("
                        SELECT sg.*, p.name as product_name, p.image as product_image, p.price as product_price
                        FROM surprise_gifts sg
                        JOIN products p ON sg.product_id = p.id
                        WHERE sg.is_active = 1
                        AND (sg.start_date IS NULL OR sg.start_date <= CURDATE())
                        AND (sg.end_date IS NULL OR sg.end_date >= CURDATE())
                        AND p.stock_quantity > 0
                        ORDER BY sg.probability_percentage DESC
                        LIMIT 2
                    ");
                    $stmt->execute();
                    $availableGifts = $stmt->fetchAll();
                    
                    if (isset($availableGifts[$selectedGiftIndex])) {
                        $gift = $availableGifts[$selectedGiftIndex];
                        if ($surpriseGiftHelper->isUserEligibleForGift($userId, $gift['id']) && 
                            !$surpriseGiftHelper->hasGiftReachedMaxUses($gift)) {
                            $selectedSurpriseGift = $gift;
                        }
                    }
                }
                
                // If no gift selected from cart, try automatic selection
                if (!$selectedSurpriseGift) {
                    $selectedSurpriseGift = $surpriseGiftHelper->selectSurpriseGift($userId, $finalTotalWithPackaging, $userOrderCount);
                }
                
                if ($selectedSurpriseGift) {
                    error_log("Surprise gift selected: " . $selectedSurpriseGift['name']);
                    $giftAdded = $surpriseGiftHelper->addSurpriseGiftToOrder($userId, $orderId, $selectedSurpriseGift);
                    if (!$giftAdded) {
                        error_log("Warning: Failed to add surprise gift to order");
                    }
                }

                // Create order items
                foreach ($cartItems as $item) {
                    error_log("Creating order item for product " . $item['product_id']);
                    $stmt = $this->pdo->prepare("
                        INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price)
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $orderId,
                        $item['product_id'],
                        $item['quantity'],
                        $item['price'],
                        $item['price'] * $item['quantity']
                    ]);

                    // Update product stock
                    $stmt = $this->pdo->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?");
                    $stmt->execute([$item['quantity'], $item['product_id']]);
                }

                // Update coupon usage if applied
                if ($appliedCoupon) {
                    $stmt = $this->pdo->prepare("
                        UPDATE coupons 
                        SET used_count = used_count + 1 
                        WHERE id = ?
                    ");
                    $stmt->execute([$appliedCoupon['id']]);
                    error_log("Coupon usage updated for coupon ID: " . $appliedCoupon['id']);
                }

                // Clear cart
                $stmt = $this->pdo->prepare("DELETE FROM cart_items WHERE user_id = ?");
                $stmt->execute([$userId]);

                // Clear applied coupon from session
                unset($_SESSION['applied_coupon']);

                $this->pdo->commit();
                error_log("Order processing completed successfully. Order ID: " . $orderId);

                // Redirect to success page
                $this->redirect('/checkout/success?order_id=' . $orderId);
            } catch (Exception $e) {
                $this->pdo->rollBack();
                error_log("ERROR in order processing: " . $e->getMessage());
                error_log("Stack trace: " . $e->getTraceAsString());
                echo "Order processing failed: " . $e->getMessage();
            }
        } else {
            error_log("ERROR: Not a POST request");
            $this->redirect('/checkout');
        }
    }
    
    private function getUserOrderCount($userId) {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as count FROM orders WHERE user_id = ?");
        $stmt->execute([$userId]);
        return $stmt->fetch()['count'];
    }
}
?>