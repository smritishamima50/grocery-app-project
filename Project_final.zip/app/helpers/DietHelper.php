<?php

class DietHelper {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    /**
     * Get user's active diet profile
     */
    public function getUserDietProfile($userId) {
        $stmt = $this->pdo->prepare("SELECT * FROM user_diet_profiles WHERE user_id = ? AND active = TRUE");
        $stmt->execute([$userId]);
        return $stmt->fetch();
    }

    /**
     * Save or update user diet profile
     */
    public function saveDietProfile($userId, $dietGoal, $calorieTarget, $currentWeight = null, $targetWeight = null, $height = null, $age = null, $activityLevel = 'moderately_active', $preferences = null) {
        try {
            // Start transaction
            $this->pdo->beginTransaction();
            
            // First, delete any existing active profile to avoid constraint issues
            $stmt = $this->pdo->prepare("DELETE FROM user_diet_profiles WHERE user_id = ? AND active = TRUE");
            $stmt->execute([$userId]);

            // Calculate BMI if height and weight are provided
            $bmi = null;
            if ($height > 0 && $currentWeight > 0) {
                $heightInMeters = $height / 100;
                $bmi = round($currentWeight / ($heightInMeters * $heightInMeters), 1);
            }

            // Insert new active profile
            $stmt = $this->pdo->prepare("INSERT INTO user_diet_profiles (user_id, diet_goal, calorie_target, current_weight, target_weight, height, age, activity_level, bmi, dietary_preferences, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE)");
            $preferencesJson = $preferences ? json_encode($preferences) : null;
            $stmt->execute([$userId, $dietGoal, $calorieTarget, $currentWeight, $targetWeight, $height, $age, $activityLevel, $bmi, $preferencesJson]);
            
            $newId = $this->pdo->lastInsertId();
            
            // Commit transaction
            $this->pdo->commit();
            
            return $newId;
        } catch (Exception $e) {
            // Rollback transaction on error
            $this->pdo->rollback();
            throw $e;
        }
    }

    /**
     * Get recommended products based on user's diet profile
     */
    public function getRecommendedProducts($userId, $limit = 12) {
        $profile = $this->getUserDietProfile($userId);
        
        // Ensure limit is an integer to prevent SQL injection
        $limit = (int)$limit;
        
        if (!$profile) {
            // Return all products if no diet profile
            $stmt = $this->pdo->prepare("
                SELECT p.*, c.name as category_name 
                FROM products p 
                LEFT JOIN categories c ON p.category_id = c.id 
                WHERE p.stock_quantity > 0 
                LIMIT $limit
            ");
            $stmt->execute();
            return $stmt->fetchAll();
        }

        $dietGoal = $profile['diet_goal'];
        $calorieTarget = $profile['calorie_target'];

        $whereClauses = [];
        $params = [];

        // Filter based on diet goal
        switch ($dietGoal) {
            case 'weight_loss':
                $whereClauses[] = "is_weight_loss_friendly = TRUE AND calories_per_unit <= 150";
                break;
            case 'muscle_gain':
                $whereClauses[] = "is_muscle_gain_friendly = TRUE AND protein_per_unit >= 5";
                break;
            case 'diabetes_friendly':
                $whereClauses[] = "is_diabetes_friendly = TRUE AND carbs_per_unit <= 20";
                break;
            case 'low_sodium':
                $whereClauses[] = "sodium_per_unit <= 100";
                break;
            case 'vegetarian':
                $whereClauses[] = "is_vegetarian = TRUE";
                break;
            case 'general':
            default:
                break;
        }

        // Base query
        $whereClause = !empty($whereClauses) ? "WHERE " . implode(" AND ", $whereClauses) . " AND stock_quantity > 0" : "WHERE stock_quantity > 0";

        // Order by relevance to diet goal
        $orderBy = $this->getOrderByClause($dietGoal);

        $sql = "SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id $whereClause ORDER BY $orderBy LIMIT $limit";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Get order by clause based on diet goal
     */
    private function getOrderByClause($dietGoal) {
        switch ($dietGoal) {
            case 'weight_loss':
                return "calories_per_unit ASC, fiber_per_unit DESC";
            case 'muscle_gain':
                return "protein_per_unit DESC, calories_per_unit DESC";
            case 'diabetes_friendly':
                return "carbs_per_unit ASC, fiber_per_unit DESC";
            case 'low_sodium':
                return "sodium_per_unit ASC";
            default:
                return "created_at DESC";
        }
    }

    /**
     * Check if product matches diet profile
     */
    public function isProductSuitable($product, $userId) {
        $profile = $this->getUserDietProfile($userId);
        
        if (!$profile) {
            return true; // No restrictions if no profile
        }

        $dietGoal = $profile['diet_goal'];

        switch ($dietGoal) {
            case 'weight_loss':
                return $product['is_weight_loss_friendly'] && $product['calories_per_unit'] <= 200;
            case 'muscle_gain':
                return $product['is_muscle_gain_friendly'];
            case 'diabetes_friendly':
                return $product['is_diabetes_friendly'] && $product['carbs_per_unit'] <= 25;
            case 'low_sodium':
                return $product['sodium_per_unit'] <= 150;
            case 'vegetarian':
                return $product['is_vegetarian'];
            default:
                return true;
        }
    }

    /**
     * Get nutrition summary for products in cart
     */
    public function getCartNutritionSummary($userId) {
        $stmt = $this->pdo->prepare("
            SELECT 
                SUM(p.calories_per_unit * ci.quantity) as total_calories,
                SUM(p.protein_per_unit * ci.quantity) as total_protein,
                SUM(p.carbs_per_unit * ci.quantity) as total_carbs,
                SUM(p.fat_per_unit * ci.quantity) as total_fat,
                SUM(p.fiber_per_unit * ci.quantity) as total_fiber,
                SUM(p.sodium_per_unit * ci.quantity) as total_sodium
            FROM cart_items ci
            JOIN products p ON ci.product_id = p.id
            WHERE ci.user_id = ?
        ");
        $stmt->execute([$userId]);
        return $stmt->fetch();
    }
}

?>
